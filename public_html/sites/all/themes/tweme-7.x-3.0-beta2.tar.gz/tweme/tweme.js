(function($) {
  $(function () {
    // ...
  });
})(jQuery);
