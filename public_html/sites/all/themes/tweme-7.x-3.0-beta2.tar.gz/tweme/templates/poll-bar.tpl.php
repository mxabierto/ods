<h5>
  <small class="pull-right"><?php print $percentage ?>%</small>
  <?php print $title ?>
</h5>
<div class="progress">
  <div class="progress-bar" style="width: <?php print $percentage ?>%"></div>
</div>
